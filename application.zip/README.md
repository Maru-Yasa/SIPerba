
## Installation

Install calculator_lrfd with git
```bash
  git clone https://github.com/NicoIzumi30/calculator_lrfd.git
  cd calculator_lrfd
```
1. Export database ke phpmyadmin
2. buka http://localhost/calculator_lrfd untuk menjalankan website (port 80)
3. buka http://localhost:port/calculator_lrfd untuk menjalankan website (untuk port selain 80)